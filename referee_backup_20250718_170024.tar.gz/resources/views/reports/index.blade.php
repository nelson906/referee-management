@extends('layouts.admin')
@section('title', 'Report')
@section('content')
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-bold text-gray-900 mb-6">Report in sviluppo</h1>
    <p class="text-gray-600">Questa funzionalità è in fase di sviluppo.</p>
</div>
@endsection
