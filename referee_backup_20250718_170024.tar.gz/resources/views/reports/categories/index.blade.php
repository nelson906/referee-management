@extends('layouts.admin')
@section('content')
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-bold text-gray-900 mb-6">Report Categorie</h1>
    <div class="bg-white rounded-lg shadow p-6">
        <p class="text-gray-600">Report categorie in sviluppo...</p>
    </div>
</div>
@endsection
