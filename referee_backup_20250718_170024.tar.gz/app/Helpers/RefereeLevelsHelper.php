<?php

namespace App\Helpers;

/**
 * RefereeLevelsHelper - Gestione centralizzata e backward compatible
 *
 * Questo helper risolve il problema delle diverse formulazioni di livelli referee
 * presenti nel sistema esistente e fornisce un'interfaccia unificata.
 */
class RefereeLevelsHelper
{
    /**
     * Mapping canonico dei livelli (FORMATO STANDARD)
     */
    const CANONICAL_LEVELS = [
        'aspirante' => 'Aspirante',
        'primo_livello' => 'Primo Livello',
        'regionale' => 'Regionale',
        'nazionale' => 'Nazionale',
        'internazionale' => 'Internazionale',
        'archivio' => 'Archivio', // Per referee inattivi
    ];

    /**
     * Mapping per BACKWARD COMPATIBILITY - tutte le varianti trovate nel sistema
     */
    const LEVEL_ALIASES = [
        // Varianti lowercase/uppercase
        'ASPIRANTE' => 'aspirante',
        'Aspirante' => 'aspirante',
        'PRIMO_LIVELLO' => 'primo_livello',
        'Primo_Livello' => 'primo_livello',
        'REGIONALE' => 'regionale',
        'Regionale' => 'regionale',
        'NAZIONALE' => 'nazionale',
        'Nazionale' => 'nazionale',
        'INTERNAZIONALE' => 'internazionale',
        'Internazionale' => 'internazionale',

        // Varianti con numeri
        '1_livello' => 'primo_livello',
        '1livello' => 'primo_livello',
        'primo-livello' => 'primo_livello',
        'primollivello' => 'primo_livello',

        // Varianti abbreviate
        'asp' => 'aspirante',
        'prim' => 'primo_livello',
        'reg' => 'regionale',
        'naz' => 'nazionale',
        'int' => 'internazionale',

        // Varianti legacy che potrebbero esistere
        'first_level' => 'primo_livello',
        'regional' => 'regionale',
        'national' => 'nazionale',
        'international' => 'internazionale',

        // Varianti con spazi
        'primo livello' => 'primo_livello',
        'Primo Livello' => 'primo_livello',
    ];

    /**
     * Ottieni tutti i livelli in formato select-friendly
     *
     * @param bool $includeArchived Include livello archivio
     * @return array
     */
    public static function getSelectOptions(bool $includeArchived = false): array
    {
        $levels = self::CANONICAL_LEVELS;

        if (!$includeArchived) {
            unset($levels['archivio']);
        }

        return $levels;
    }

    /**
     * Normalizza un livello da qualsiasi variante al formato canonico
     *
     * @param string|null $level
     * @return string|null
     */
    public static function normalize(?string $level): ?string
    {
        if (empty($level)) {
            return null;
        }

        // Se è già in formato canonico, restituisci così com'è
        if (array_key_exists($level, self::CANONICAL_LEVELS)) {
            return $level;
        }

        // Cerca negli alias
        if (array_key_exists($level, self::LEVEL_ALIASES)) {
            return self::LEVEL_ALIASES[$level];
        }

        // Prova case-insensitive matching
        $levelLower = strtolower($level);
        if (array_key_exists($levelLower, self::CANONICAL_LEVELS)) {
            return $levelLower;
        }

        // Prova negli alias case-insensitive
        foreach (self::LEVEL_ALIASES as $alias => $canonical) {
            if (strtolower($alias) === $levelLower) {
                return $canonical;
            }
        }

        // Se non trovato, log warning e restituisci il valore originale
        \Log::warning("RefereeLevelsHelper: Unknown level variant", [
            'input_level' => $level,
            'suggestion' => 'Add to LEVEL_ALIASES array'
        ]);

        return $level; // Restituisci originale per non rompere il sistema
    }

    /**
     * Ottieni il label di un livello
     *
     * @param string|null $level
     * @return string
     */
    public static function getLabel(?string $level): string
    {
        if (empty($level)) {
            return 'Non specificato';
        }

        $normalized = self::normalize($level);

        return self::CANONICAL_LEVELS[$normalized] ?? ucfirst($level);
    }

    /**
     * Verifica se un livello è valido
     *
     * @param string|null $level
     * @return bool
     */
    public static function isValid(?string $level): bool
    {
        if (empty($level)) {
            return false;
        }

        $normalized = self::normalize($level);
        return array_key_exists($normalized, self::CANONICAL_LEVELS);
    }

    /**
     * Verifica se un livello può accedere a tornei nazionali
     *
     * @param string|null $level
     * @return bool
     */
    public static function canAccessNationalTournaments(?string $level): bool
    {
        $normalized = self::normalize($level);
        return in_array($normalized, ['nazionale', 'internazionale']);
    }

    /**
     * Ottieni tutti gli alias possibili per debugging
     *
     * @return array
     */
    public static function getAllVariants(): array
    {
        return array_merge(
            array_keys(self::CANONICAL_LEVELS),
            array_keys(self::LEVEL_ALIASES)
        );
    }

    /**
     * Migra/aggiorna un array di livelli dal formato legacy al canonico
     * Utile per migration di dati esistenti
     *
     * @param array $levels
     * @return array
     */
    public static function migrateLevels(array $levels): array
    {
        $migrated = [];

        foreach ($levels as $key => $value) {
            $normalizedKey = self::normalize($key);
            $migrated[$normalizedKey] = $value;
        }

        return $migrated;
    }

    /**
     * Debug helper - trova quale variante è stata usata
     *
     * @param string $level
     * @return array
     */
    public static function debugLevel(string $level): array
    {
        return [
            'original' => $level,
            'normalized' => self::normalize($level),
            'label' => self::getLabel($level),
            'is_valid' => self::isValid($level),
            'can_access_national' => self::canAccessNationalTournaments($level),
            'found_in_canonical' => array_key_exists($level, self::CANONICAL_LEVELS),
            'found_in_aliases' => array_key_exists($level, self::LEVEL_ALIASES),
        ];
    }
}

/**
 * Helper function globale per facilità d'uso
 */
if (!function_exists('referee_levels')) {
    function referee_levels(bool $includeArchived = false): array
    {
        return RefereeLevelsHelper::getSelectOptions($includeArchived);
    }
}

if (!function_exists('normalize_referee_level')) {
    function normalize_referee_level(?string $level): ?string
    {
        return RefereeLevelsHelper::normalize($level);
    }
}

if (!function_exists('referee_level_label')) {
    function referee_level_label(?string $level): string
    {
        return RefereeLevelsHelper::getLabel($level);
    }
}
