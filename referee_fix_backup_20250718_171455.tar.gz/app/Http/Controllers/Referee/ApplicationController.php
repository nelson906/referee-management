<?php

namespace App\Http\Controllers\Referee;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ApplicationController extends Controller
{
    //
}
